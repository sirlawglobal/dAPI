const express = require("express");
const UserController = require("../controllers/userController");
const router = express.Router();
const checkAuth = require('../middleware/authMiddleware.js');

// Route for creating a new user
router.post("/signup", UserController.createUser);
router.post("/login", UserController.loginUser);
router.post("/forgotPassword", UserController.forgotPassword);
router.post("/resetPassword", UserController.resetPassword);

module.exports = router;

// 
