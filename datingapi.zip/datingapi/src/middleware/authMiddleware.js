const checkAuth = (req, res, next) => {
  const userSession = req.cookies.userSession;

  if (!userSession) {
    return res.status(401).json({ message: "Unauthorized. Please log in." });
  }

  req.user = userSession; // Attach session data to the request object
  next();
};

module.exports = checkAuth;
