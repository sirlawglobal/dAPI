const db = require("../config/db");

exports.createUser = (userData, callback) => {
  const query = `
    INSERT INTO users (
      username, email, password, profession, height, weight, country, city, birthday, 
      gender, relationship_goals, distance_preference, interest, education_level, bio
    ) 
    VALUES (
      '${userData.username}', 
      '${userData.email}', 
      '${userData.password}', 
      '${userData.profession}', 
      '${userData.height}', 
      '${userData.weight}', 
      '${userData.country}', 
      '${userData.city}', 
      '${userData.birthday}', 
      '${userData.gender}', 
      '${userData.relationship_goals}', 
      '${userData.distance_preference}', 
      '${userData.interest}', 
      '${userData.education_level}', 
      '${userData.bio}'
    )
  `;

  // Execute the query
  db.query(query, callback);
};


exports.findUserByEmail = (email) => {
  return new Promise((resolve, reject) => {
    const query = "SELECT * FROM users WHERE email = ?";
    db.query(query, [email], (err, results) => {
      if (err) {
          console.error(err)
        reject(err);
      } else {
        resolve(results);
      }
    });

  });
};


exports.findUserByResetToken = (token) => {
  return new Promise((resolve, reject) => {
    const query = "SELECT * FROM users WHERE reset_token = ?";
    db.query(query, [token], (err, results) => {
      if (err) {
          console.error(err)
        reject(err);
      } else {
        resolve(results[0]);
      }
    });
  });
};

exports.updatePassword = (userId, newPassword) => {
  return new Promise((resolve, reject) => {
    const query = "UPDATE users SET password = ? WHERE id = ?";
    db.query(query, [newPassword, userId], (err, results) => {
      if (err) {
          console.error(err)
        reject(err);
      } else {
        resolve(results);
      }
    });
  });
};


// / Function to update the reset token and expiration in the database
exports.updateResetToken = (email, resetToken, resetExpiration) => {
  return new Promise((resolve, reject) => {
    const query = `
      UPDATE users
      SET reset_token = ?, resetPasswordExpires = ?
      WHERE email = ?
    `;
    db.query(query, [resetToken, resetExpiration, email], (err, results) => {
      if (err) {
        reject(err);
      } else {
        resolve(results);
      }
    });
  });
};