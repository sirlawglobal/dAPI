// const bcrypt = require("bcrypt");
const bcrypt = require('bcryptjs');
require('dotenv').config();
const User = require("../models/userModel.js");
const jwt = require("jsonwebtoken");
const winston = require("winston");
const crypto = require('crypto');
const nodemailer = require('nodemailer');


exports.createUser = async (req, res) => {
  try {
    const {
      username,
      email,
      password,
      profession,
      height,
      weight,
      country,
      city,
      birthday,
      gender,
      relationship_goals,
      distance_preference,
      interest,
      education_level,
      bio
    } = req.body;

    // Validate required fields
    if (!username || !email || !password) {
      return res.status(400).json({ message: "Username, email, and password are required." });
    }

    // Hash the password
    const hashedPassword = await bcrypt.hash(password, 10);

    // Data to insert
    const userData = {
      username,
      email,
      password: hashedPassword,
      profession,
      height,
      weight,
      country,
      city,
      birthday,
      gender,
      relationship_goals,
      distance_preference,
      interest,
      education_level,
      bio
    };

    // Call the User model to create a new user
    User.createUser(userData, (err, results) => {
      if (err) {
        return res.status(500).json({ error: err.message });
      }
      res.status(201).json({ message: "User created successfully.", userId: results.insertId });
    });
  } catch (error) {
    res.status(500).json({ error: "An internal error occurred." });
  }
};


// Set up the logger to log to a file
const logger = winston.createLogger({
  transports: [
    new winston.transports.File({ filename: 'logs/error.log', level: 'error' }),
    new winston.transports.Console({ format: winston.format.simple() })
  ]
});


exports.loginUser = async (req, res) => {
  const { email, password } = req.body;

  // Validate required fields
  if (!email || !password) {
    return res.status(400).json({ message: "Email and password are required." });
  }

  try {
    // Query the database for the user by email
    const results = await User.findUserByEmail(email);

    // If no user is found
    if (!results || results.length === 0) {
      return res.status(404).json({ message: "User not found." });
    }

    const user = results[0]; // Assuming the result is a single user

    // Compare the provided password with the hashed password in the database
    const isMatch = await bcrypt.compare(password, user.password);

    // If password does not match
    if (!isMatch) {
      return res.status(401).json({ message: "Invalid credentials." });
    }

    // Create a session object to store in the cookie
    const sessionData = {
      userId: user.id,
      username: user.username,
    };

    // Set the session data in the cookie
    res.cookie('userSession', sessionData, {
      httpOnly: true, // Ensures the cookie is only accessible via HTTP(S)
      secure: true,   // Ensures the cookie is only sent over HTTPS (enable in production)
      maxAge: 60 * 60 * 1000, // Cookie expiry: 1 hour
    });

    // Send a success response
    res.status(200).json({
      message: "Login successful.",
      userId: user.id,
      username: user.username,
    });
  } catch (error) {
    // Log the error to troubleshoot
    console.error("Error during login:", error);

    res.status(500).json({ error: "An internal error occurred.", details: error.message });
  }
};




exports.forgotPassword = async (req, res) => {
  const { email } = req.body;

  if (!email) {
    return res.status(400).json({ message: "Email is required." });
  }

  try {
    // Check if user exists in the database
    const user = await User.findUserByEmail(email);
    if (!user || user.length === 0) {
      return res.status(404).json({ message: "User not found." });
    }

    // Generate a random reset token
    const resetToken = crypto.randomBytes(20).toString('hex');

    // Prepare the expiration time (1 hour from now)
    const resetExpiration = Date.now() + 3600000; // 1 hour expiration

    // Update the user's reset token and expiration in the database using the model function
    await User.updateResetToken(email, resetToken, resetExpiration);

    // Send reset email using Nodemailer
    const resetUrl = `http://datingapi.dgn128.pro/reset-password?token=${resetToken}`;
    const transporter = nodemailer.createTransport({
      service: 'Gmail',
      auth: {
        user: 'akanjilawrence9999@gmail.com',
        pass: 'Ayobami7#',
      },
    });

    const mailOptions = {
      from: 'akanjilawrence9999@gmail.com',
      to: email,
      subject: 'Password Reset Request',
      text: `You requested a password reset. Click the link to reset your password: ${resetUrl}`,
    };

    // Send the email
    transporter.sendMail(mailOptions, (err, info) => {
      if (err) {
        console.error("Error sending email:", err);
        return res.status(500).json({ error: 'Failed to send email.' });
      }

      // Successfully sent email
      res.status(200).json({ message: 'Password reset email sent.' });
    });
  } catch (error) {
      
      logger.error('Detailed error message: ', error);
    console.error("Error during password reset:", error);
    res.status(500).json({ error: "An internal error occurred.", details: error.message });
  }
};


exports.resetPassword = async (req, res) => {
  const { token, newPassword } = req.body;

  if (!token || !newPassword) {
    return res.status(400).json({ message: 'Token and new password are required.' });
  }

  try {
    const user = await User.findUserByResetToken(token);
    if (!user || user.tokenExpiration < Date.now()) {
      return res.status(400).json({ message: 'Invalid or expired reset token.' });
    }

    const hashedPassword = await bcrypt.hash(newPassword, 10);
    await User.updatePassword(user.id, hashedPassword);
    res.status(200).json({ message: 'Password has been reset successfully.' });
  } catch (error) {
    logger.error(`Error during password reset: ${error.message}`);
    res.status(500).json({ message: 'An internal error occurred.' });
  }
};

